import { 
  CircleDollarSign,
  TrendingUp,
  ShieldCheck,
  Bitcoin,
  Globe,
  Zap,
  Smartphone,
  UserCheck,
  Lock
} from 'lucide-react';

export interface QuizQuestion {
  question: string;
  options: string[]; 
}

export interface Tool {
  name: string;
  type: 'CALCULATOR' | 'HASH' | 'VISUALIZER' | 'SIMULATOR';
  description: string;
  troubleshoot: string[];
}

export interface KnowledgeItem {
  id: string;
  title: string;
  content: string; 
  facts: {
    satoshi: string;
    bitcoiner: { name: string; quote: string };
    random: string;
  };
  tool: Tool;
  quiz: QuizQuestion[];
}

export const knowledgeBase: KnowledgeItem[] = [
  // CHAPTER 1: THE PROBLEM
  {
    id: "1.1",
    title: "The Trading Game",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">What is Money?</h3>
      <p class="mb-4">Imagine you have an apple and I have a banana. We want to swap. That is easy! But what if I want your apple, but I don't have a banana? I only have a chicken?</p>
      <p class="mb-6">Money is a tool that helps us swap things easily without carrying chickens around. It is a way to "save" your hard work today so you can buy something tomorrow.</p>
      <div class="bg-blue-50 p-6 rounded-2xl border-l-4 border-blue-500 mb-6">
        <h4 class="font-bold text-blue-800 uppercase mb-2">Think About It</h4>
        <p class="text-blue-700 font-medium">If money is just a tool for trading, what happens if that tool starts to break or becomes too heavy to use?</p>
      </div>
    `,
    facts: {
      satoshi: "Money is just a way to keep track of who did work for whom.",
      bitcoiner: { name: "Robert Breedlove", quote: "Money is the medium of human action." },
      random: "Long ago, people used pretty sea shells as money!"
    },
    tool: {
      name: "BitTrade",
      type: "VISUALIZER",
      description: "See why carrying chickens is harder than carrying Bitcoin.",
      troubleshoot: ["Select 'Chicken' vs 'Sats'.", "Try to send them to a friend far away.", "Notice which one is faster!"]
    },
    quiz: [
      { question: "What is money mainly used for?", options: ["Swapping things easily", "Eating for dinner", "Making paper airplanes", "Hiding in the garden"] },
      { question: "Why are chickens bad money?", options: ["Hard to carry and they poop", "They are too delicious", "They speak too many languages", "They are too small"] }
    ]
  },
  {
    id: "1.2",
    title: "The Money Thief",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">What is Inflation?</h3>
      <p class="mb-4">Imagine you have a full bottle of milk. Every night, someone sneaks in and drinks a little bit, then adds water to make it look full again.</p>
      <p class="mb-6">In a few weeks, your milk is just cloudy water. It doesn't give you energy anymore. This is <strong>Inflation</strong>. When more money is printed, the money in your pocket buys less bread and milk every day.</p>
    `,
    facts: {
      satoshi: "The history of fiat currencies is full of breaches of trust.",
      bitcoiner: { name: "Saifedean Ammous", quote: "Inflation is theft." },
      random: "One time in history, a loaf of bread cost a whole wheelbarrow of money!"
    },
    tool: {
      name: "BitCalc",
      type: "CALCULATOR",
      description: "See how fast your 'Milk' (Savings) turns into water.",
      troubleshoot: ["Enter your KES amount.", "Watch the value drop over years.", "The red number is the lost value."]
    },
    quiz: [
      { question: "What does inflation do to your money?", options: ["Makes it buy less things", "Makes it grow like a tree", "Makes it turn into gold", "Makes it smell better"] },
      { question: "If a soda costs 50 KES today and 100 KES tomorrow, what likely happened?", options: ["Inflation (Money lost value)", "The soda got bigger", "The shop is giving a gift", "It is magic"] }
    ]
  },
  {
    id: "1.3",
    title: "The Bank Trap",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">Whose Money is it?</h3>
      <p class="mb-4">When you put money in a bank, it is not actually in your hands anymore. You are giving the bank a loan, and you often have to ask for <strong>permission</strong> to spend it.</p>
      <p class="mb-6">If the bank is closed, or if they decide to block a payment, you are stuck. True financial freedom means being able to use your money whenever you want, without asking anyone.</p>
    `,
    facts: {
      satoshi: "Banks must be trusted to hold our money, but they lend it out in waves of credit bubbles.",
      bitcoiner: { name: "Jack Mallers", quote: "The current system is a closed loop." },
      random: "Banks sometimes charge you fees just to keep your own money there!"
    },
    tool: {
      name: "BitGate",
      type: "SIMULATOR",
      description: "Try to send money through the Bank Gate.",
      troubleshoot: ["Click 'Send Payment'.", "Watch the Gatekeeper decide.", "Try it on a Sunday when they are closed!"]
    },
    quiz: [
      { question: "Do you truly own the money inside a bank account?", options: ["No, it is a loan to the bank", "Yes, it is in my pocket", "Only on Saturdays", "Yes, the manager promised"] },
      { question: "What is a main problem with centralized banks?", options: ["Needing permission to use your money", "They give away too much free gold", "They are too fast", "They have too many toys"] }
    ]
  },

  // CHAPTER 2: THE SOLUTION
  {
    id: "2.1",
    title: "Digital Gold",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">Only 21 Million</h3>
      <p class="mb-4">Why is gold valuable? Because it is hard to find! You can't just print more gold. Bitcoin is similar, but it lives on the internet as the first 'Hard Asset'.</p>
      <p class="mb-6">There will only ever be <strong>21 Million Bitcoin</strong>. No king, president, or bank can make more. This absolute scarcity ensures your share of the network is never diluted.</p>
    `,
    facts: {
      satoshi: "Total circulation will be 21,000,000 coins.",
      bitcoiner: { name: "Michael Saylor", quote: "Bitcoin is digital property." },
      random: "There are more atoms in a single grain of sand than there are Bitcoins!"
    },
    tool: {
      name: "BitScarcity",
      type: "VISUALIZER",
      description: "See the 21 Million cap vs Infinite printing.",
      troubleshoot: ["Press 'Print Fiat'.", "Watch the screen fill up.", "Compare it to the fixed Bitcoin box."]
    },
    quiz: [
      { question: "How many Bitcoins will there ever be?", options: ["21 Million", "Infinite", "100", "One for every person"] },
      { question: "Why is scarcity a good property for money?", options: ["It helps store value over time", "It makes it easier to lose", "It makes it look pretty", "It makes it heavy"] }
    ]
  },
  {
    id: "2.2",
    title: "The Notebook",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">The Blockchain</h3>
      <p class="mb-4">Imagine a giant notebook that everyone in the world can see, but no one can erase. When a transaction happens, it is written in this public record.</p>
      <p class="mb-6">Since thousands of people have a copy of this notebook, no one can lie about their balance. This is the <strong>Blockchain</strong>—a decentralized machine for truth.</p>
    `,
    facts: {
      satoshi: "The system is secure as long as honest nodes collectively control the network.",
      bitcoiner: { name: "Andreas Antonopoulos", quote: "Bitcoin is the internet of money." },
      random: "The first block ever written is called the 'Genesis Block'."
    },
    tool: {
      name: "BitHash",
      type: "HASH",
      description: "Try to write a page in the Truth Machine.",
      troubleshoot: ["Type a message in the box.", "Watch the code change.", "Try to find a code starting with '0'."]
    },
    quiz: [
      { question: "Can you easily erase a transaction on the Blockchain?", options: ["No, it is permanent", "Yes, with an eraser", "Only if you call support", "Only on holidays"] },
      { question: "Who maintains the Bitcoin 'notebook'?", options: ["The network of nodes", "Only the President", "Only the banks", "The Bitcoin CEO"] }
    ]
  },
  {
    id: "2.3",
    title: "Laser Beam",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">The Lightning Network</h3>
      <p class="mb-4">While the main Bitcoin network is slow and safe, 'Lightning' is like a laser beam! it lets you send tiny amounts of money instantly for almost zero cost.</p>
      <p class="mb-6">This is perfect for everyday things like buying coffee or airtime. It makes Bitcoin practical for daily use across Kenya.</p>
    `,
    facts: {
      satoshi: "The network is robust in its unstructured simplicity.",
      bitcoiner: { name: "Elizabeth Stark", quote: "Lightning is the future of payments." },
      random: "You can send as little as 1 'Sat' (0.00000001 BTC) on Lightning!"
    },
    tool: {
      name: "BitLaser",
      type: "SIMULATOR",
      description: "Race a Bank Wire vs Lightning.",
      troubleshoot: ["Press 'START'.", "Watch the laser (Lightning) win.", "Wait 3 days for the bank wire."]
    },
    quiz: [
      { question: "What is the Lightning Network best for?", options: ["Small, fast daily payments", "Saving for 100 years", "Buying a skyscraper", "Storing gold bars"] },
      { question: "How fast is a Lightning payment compared to a bank?", options: ["Instant vs Days", "Same speed", "Slower", "10 Minutes"] }
    ]
  },

  // CHAPTER 3: THE PRACTICE
  {
    id: "3.1",
    title: "Your First App",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">Be Your Own Bank</h3>
      <p class="mb-4">To use Bitcoin, you need a digital wallet app. Unlike a banking app, <strong>you</strong> are the only one with the keys to your money.</p>
      <p class="mb-6">Your wallet has a 'Bitcoin Address' (like a payment ID). You can receive money from anyone, anywhere, instantly, without a middleman.</p>
    `,
    facts: {
      satoshi: "A purely peer-to-peer version of electronic cash.",
      bitcoiner: { name: "Adam Back", quote: "Self-custody is the goal." },
      random: "You can create a new wallet in less than 30 seconds!"
    },
    tool: {
      name: "BitWallet",
      type: "SIMULATOR",
      description: "Practice receiving a payment.",
      troubleshoot: ["Show your QR code.", "Wait for the confirmation.", "Check your balance."]
    },
    quiz: [
      { question: "Who controls the money in your private Bitcoin wallet?", options: ["The owner (Me)", "The bank", "The app developer", "The government"] },
      { question: "What do you show someone to receive sats?", options: ["My QR Code or Address", "My private seed words", "My ID card", "My Facebook password"] }
    ]
  },
  {
    id: "3.2",
    title: "Face to Face",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">Trading P2P</h3>
      <p class="mb-4">The best way to get Bitcoin is to earn it or trade for it directly with another person. This is called P2P (Peer-to-Peer).</p>
      <p class="mb-6">In Kenya, we use the 'Keep Spedn' philosophy. You meet a trusted person, send them KES, and they send Bitcoin directly to your wallet. It's fast and private.</p>
    `,
    facts: {
      satoshi: "Lost coins only make everybody else's coins worth slightly more.",
      bitcoiner: { name: "Paco de la India", quote: "Bitcoin is freedom." },
      random: "Most people in Nairobi use Telegram groups to find P2P traders."
    },
    tool: {
      name: "BitEscrow",
      type: "SIMULATOR",
      description: "Simulate a safe P2P trade.",
      troubleshoot: ["Lock the BTC.", "Send the cash.", "Release the coins."]
    },
    quiz: [
      { question: "What does P2P mean?", options: ["Peer-to-Peer", "Price-to-Pay", "Paper-to-Power", "Public-to-Private"] },
      { question: "Why is P2P trading popular in Kenya?", options: ["It is direct and private", "It is mandatory by law", "It takes 5 days", "It requires a physical bank"] }
    ]
  },
  {
    id: "3.3",
    title: "The Secret Words",
    content: `
      <h3 class="text-2xl font-bold uppercase mb-4 text-black">The 12-Word Backup</h3>
      <p class="mb-4">If your phone breaks, your Bitcoin isn't gone—if you have your 12 secret words! These words are the master key to your funds.</p>
      <p class="mb-6"><strong>NEVER</strong> share these words or type them into any website. Write them on paper or metal and hide them safely. If you lose them, you lose your money.</p>
    `,
    facts: {
      satoshi: "If you don't believe me or don't get it, I don't have time to try to convince you, sorry.",
      bitcoiner: { name: "Gigi", quote: "Bitcoin is a tool for peace." },
      random: "If you lose these words, no one on earth can recover your Bitcoin!"
    },
    tool: {
      name: "BitSafe",
      type: "VISUALIZER",
      description: "Test your backup material.",
      troubleshoot: ["Select 'Paper' or 'Steel'.", "Apply 'Fire' or 'Flood'.", "See what survives."]
    },
    quiz: [
      { question: "What should you do with your 12 secret words?", options: ["Write them down and hide them offline", "Take a screenshot", "Post them on Telegram for backup", "Tell them to a stranger"] },
      { question: "Who should you give your words to if they ask online?", options: ["ABSOLUTELY NO ONE", "The Police", "Support Staff", "My best friend"] }
    ]
  }
];

export const getKnowledge = (id: string): KnowledgeItem | null => {
  return knowledgeBase.find(k => k.id === id) || null;
};