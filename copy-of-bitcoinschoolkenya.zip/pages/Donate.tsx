import React, { useState } from 'react';
import { PageLayout } from '../components/PageLayout';
import { 
  Zap, 
  Copy,
  Check,
  Heart,
  MessageSquare,
  QrCode
} from 'lucide-react';

export const Donate: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const donationAddress = "bitcoinschoolke@walletofsatoshi.com";

  const handleCopy = () => {
    navigator.clipboard.writeText(donationAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <PageLayout title="Give" subtitle="Support the Mission">
      <div className="space-y-8">
        {/* Mission Statement Card */}
        <div className="bg-white p-6 md:p-8 rounded-3xl border-4 border-black shadow-hard text-slate-800">
           <div className="flex items-center gap-3 mb-4">
              <Heart className="text-red-500" size={32} fill="currentColor" />
              <h3 className="font-display font-bold uppercase text-2xl">Fueling Education</h3>
           </div>
           <div className="prose prose-lg text-slate-700 leading-relaxed font-medium font-sans">
             <p className="mb-6">
               Your contribution bridges the gap for young learners in Kenya. We are committed to spreading financial sovereignty: <strong>21% of all contributions are strictly allocated to printing Bitcoin School resources</strong>, which we gift freely to community members.
             </p>
             <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-xl mt-6 not-prose flex gap-3 items-start">
                <MessageSquare className="text-blue-500 shrink-0 mt-1" size={20} />
                <p className="text-blue-800 font-bold text-sm leading-snug">
                  Recommended: Please add a note to your donation so we can recognize your contribution!
                </p>
             </div>
           </div>
        </div>

        {/* Single Donation Card */}
        <div className="bg-[#F7931A] text-white p-8 rounded-3xl border-4 border-black shadow-hard flex flex-col items-center text-center">
           <div className="w-20 h-20 bg-black rounded-full flex items-center justify-center mb-6 border-2 border-white shadow-hard-sm">
              <Zap className="text-[#F7931A]" size={40} fill="currentColor" />
           </div>
           
           <h3 className="font-display font-bold uppercase text-3xl text-black mb-2">Lightning Only</h3>
           <p className="text-black/80 font-bold text-sm uppercase tracking-widest mb-8">Fast • Global • Sovereign</p>

           <div className="bg-white p-6 rounded-2xl border-4 border-black w-full max-w-sm mb-6 shadow-hard-sm">
              <p className="text-[10px] font-bold uppercase text-slate-400 mb-2">Lightning Address</p>
              <p className="font-mono font-bold text-lg md:text-xl text-black break-all mb-4">
                {donationAddress}
              </p>
              <button 
                onClick={handleCopy}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold uppercase text-sm transition-all border-2 border-black bg-slate-50 hover:bg-black hover:text-white"
              >
                {copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
                {copied ? "Address Copied" : "Copy Address"}
              </button>
           </div>

           <div className="text-black/60 text-xs font-medium max-w-xs">
             <p>Scan or copy this address in any Lightning-enabled wallet (Blink, Phoenix, Wallet of Satoshi, etc.)</p>
           </div>
        </div>

        {/* Community Proof */}
        <div className="bg-slate-900 text-white p-6 rounded-2xl border-4 border-black shadow-hard text-center">
           <p className="text-sm font-bold uppercase tracking-widest mb-2">Don't Trust, Verify</p>
           <p className="text-xs text-slate-400 italic">
             "Money is a tool, but education is the power. Help us build the Bitcoin Circular Economy in Nairobi."
           </p>
        </div>
      </div>
    </PageLayout>
  );
};