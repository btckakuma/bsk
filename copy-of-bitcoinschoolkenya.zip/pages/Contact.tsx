import React from 'react';
import { PageLayout } from '../components/PageLayout';
import { BlankaText } from '../components/BlankaText';
import { 
  Send,
  ShieldAlert,
  HelpCircle,
  Mail
} from 'lucide-react';

export const Contact: React.FC = () => {
  const guidelines = [
    {
      id: "guideline-opsec",
      title: "1. Operational Security (OpSec)",
      text: "Never reveal your real name or net worth in public channels. Protect your physical safety by remaining private.",
    },
    {
      id: "guideline-phishing",
      title: "2. Seed Phrase Phishing",
      text: "Admin will NEVER ask for your seed words. If anyone asks for them, they are a scammer.",
    }
  ];

  const faqs = [
    {
      q: "How do I join the School?",
      a: "Just join our Telegram group @bitcoinschoolkenya. We are an open community of learners and builders. There is no membership fee."
    },
    {
      q: "Do I need to buy a whole Bitcoin?",
      a: "No! You can buy as little as 100 Shillings worth of Bitcoin (Satoshis)."
    }
  ];

  return (
    <PageLayout title="Contact" subtitle="Reach Out">
      <div className="space-y-12">
        
        {/* Connection Channels */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Telegram Card */}
            <div className="bg-blue-500 p-8 rounded-2xl border-4 border-black shadow-hard text-white flex flex-col items-center text-center">
               <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-4 border-2 border-white/20">
                  <Send className="text-white" size={32} />
               </div>
               <h3 className="font-display font-bold uppercase text-2xl mb-2">Telegram</h3>
               <p className="text-white/80 text-sm leading-relaxed mb-6">
                 Primary hub for community discussions and P2P trade.
               </p>
               <a 
                 href="https://t.me/bitcoinschoolkenya"
                 target="_blank"
                 rel="noopener noreferrer"
                 className="w-full bg-white text-blue-500 px-6 py-4 rounded-xl font-bold uppercase text-lg hover:bg-slate-100 transition-colors shadow-hard active:translate-y-1 active:shadow-none"
               >
                 Open Telegram
               </a>
            </div>

            {/* Email Card */}
            <div className="bg-slate-900 p-8 rounded-2xl border-4 border-black shadow-hard text-white flex flex-col items-center text-center">
               <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-4 border-2 border-white/20">
                  <Mail className="text-white" size={32} />
               </div>
               <h3 className="font-display font-bold uppercase text-2xl mb-2">Email</h3>
               <p className="text-white/80 text-sm leading-relaxed mb-6">
                 For merchant inquiries and formal collaborations.
               </p>
               <a 
                 href="mailto:bitcoinschoolkenya@gmail.com"
                 className="w-full bg-[#F7931A] text-black px-6 py-4 rounded-xl font-bold uppercase text-lg hover:bg-white transition-colors shadow-hard active:translate-y-1 active:shadow-none"
               >
                 Send Email
               </a>
            </div>
        </div>

        {/* Safety Rules */}
        <div className="bg-red-50 border-4 border-red-500 rounded-3xl p-6 md:p-8 shadow-hard">
            <div className="flex items-center gap-4 mb-6">
                <ShieldAlert className="text-red-600" size={32} />
                <BlankaText text="Safety Rules" as="h2" className="text-2xl md:text-3xl text-red-700" />
            </div>
            <div className="space-y-4">
                {guidelines.map((rule) => (
                    <div key={rule.id} className="bg-white p-6 rounded-2xl border-l-8 border-red-500 shadow-sm">
                        <h3 className="font-bold uppercase text-xl mb-2 text-black">{rule.title}</h3>
                        <p className="text-slate-700 leading-relaxed font-medium">
                            {rule.text}
                        </p>
                    </div>
                ))}
            </div>
        </div>

        {/* FAQ */}
        <div className="bg-blue-50 border-4 border-blue-500 rounded-3xl p-6 md:p-8 shadow-hard">
            <div className="flex items-center gap-4 mb-6">
                <HelpCircle className="text-blue-600" size={32} />
                <BlankaText text="F.A.Q." as="h2" className="text-2xl md:text-3xl text-blue-700" />
            </div>
            <div className="space-y-6">
                {faqs.map((item, idx) => (
                    <div key={idx} className="bg-white p-6 rounded-2xl border-2 border-blue-200">
                        <h3 className="font-bold uppercase text-lg text-blue-800 mb-3">
                           Q. {item.q}
                        </h3>
                        <p className="text-slate-600 font-medium leading-relaxed">
                            {item.a}
                        </p>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </PageLayout>
  );
};