import React from 'react';
import { PageLayout } from '../components/PageLayout';
import { useSearchParams } from 'react-router-dom';
import { 
  Bitcoin, 
  Smartphone, 
  ShieldCheck, 
  Zap, 
  Globe, 
  Lock, 
  Star, 
  Award, 
  CircleDollarSign, 
  TrendingUp, 
  UserCheck 
} from 'lucide-react';
import { BlankaText } from '../components/BlankaText';

interface LessonNodeProps {
  id: string;
  title: string;
  subtitle: string;
  icon: any;
  color: string;
  isLast?: boolean;
}

const LessonNode: React.FC<LessonNodeProps> = ({ id, title, subtitle, icon: Icon, color, isLast }) => {
  const [_, setSearchParams] = useSearchParams();
  
  const handleClick = () => {
    setSearchParams({ learn: id });
  };

  return (
    <div className="flex flex-col items-center w-full max-w-[200px] relative group">
      {!isLast && (
        <div className="absolute top-20 bottom-[-40px] w-1 lesson-path-line left-1/2 -translate-x-1/2 z-0 opacity-20 hidden md:block"></div>
      )}

      <button 
        onClick={handleClick}
        className={`w-20 h-20 md:w-24 md:h-24 rounded-full border-4 border-black ${color} flex items-center justify-center text-white shadow-hard hover:scale-110 active:translate-y-1 active:shadow-none transition-all z-10`}
      >
        <Icon size={40} strokeWidth={2.5} className="group-hover:rotate-12 transition-transform" />
        <div className="absolute -top-2 -right-2 bg-white border-2 border-black rounded-full w-8 h-8 flex items-center justify-center text-black font-black text-xs">
          {id}
        </div>
      </button>
      
      <div className="text-center mt-4 bg-white/10 backdrop-blur-sm p-3 rounded-2xl border border-white/20 w-full">
        <BlankaText text={title} className="text-white text-sm md:text-base block leading-tight mb-1" />
        <p className="text-white/60 text-[8px] md:text-[10px] font-bold uppercase tracking-widest">{subtitle}</p>
      </div>
    </div>
  );
};

export const Education: React.FC = () => {
  return (
    <PageLayout title="Study" subtitle="Master the fundamentals in 3 stages">
      <div className="space-y-16 pb-12">
        
        {/* Course Header */}
        <div className="bg-slate-900 border-4 border-black rounded-3xl p-8 shadow-hard text-center relative overflow-hidden">
           <div className="relative z-10">
              <div className="inline-flex items-center gap-2 bg-[#F7931A] text-black px-4 py-1 rounded-full text-xs font-bold uppercase mb-4 border-2 border-black">
                <Star size={14} fill="black" /> 
                Foundational Path
              </div>
              <h2 className="text-3xl md:text-5xl font-bold uppercase font-display text-white mb-4">The Learning Path</h2>
              <p className="text-slate-400 font-medium max-w-md mx-auto text-lg">
                Complete these 9 essential lessons to build a strong Bitcoin foundation.
              </p>
           </div>
           <div className="absolute -right-10 -bottom-10 opacity-10 rotate-12">
              <Bitcoin size={240} className="text-white" />
           </div>
        </div>

        {/* Path Section */}
        <div className="space-y-16">
          
          {/* Chapter 1 */}
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <div className="bg-red-500 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 border-black shadow-hard-sm">1</div>
              <h3 className="text-2xl font-bold uppercase text-white drop-shadow-md">The Problem (Why)</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 place-items-center">
               <LessonNode id="1.1" title="The Swap" subtitle="What is Money?" icon={CircleDollarSign} color="bg-red-500" />
               <LessonNode id="1.2" title="The Thief" subtitle="Inflation" icon={TrendingUp} color="bg-red-600" />
               <LessonNode id="1.3" title="The Trap" subtitle="Banks vs You" icon={ShieldCheck} color="bg-red-700" />
            </div>
          </div>

          {/* Chapter 2 */}
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <div className="bg-orange-500 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 border-black shadow-hard-sm">2</div>
              <h3 className="text-2xl font-bold uppercase text-white drop-shadow-md">The Solution (What)</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 place-items-center">
               <LessonNode id="2.1" title="Digital Gold" subtitle="Scarcity" icon={Bitcoin} color="bg-orange-500" />
               <LessonNode id="2.2" title="The Notebook" subtitle="Blockchain" icon={Globe} color="bg-orange-600" />
               <LessonNode id="2.3" title="Laser Beam" subtitle="Lightning" icon={Zap} color="bg-orange-400" />
            </div>
          </div>

          {/* Chapter 3 */}
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <div className="bg-green-500 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 border-black shadow-hard-sm">3</div>
              <h3 className="text-2xl font-bold uppercase text-white drop-shadow-md">The Practice (How)</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 place-items-center">
               <LessonNode id="3.1" title="Your App" subtitle="Wallets" icon={Smartphone} color="bg-green-500" />
               <LessonNode id="3.2" title="Face to Face" subtitle="Trade P2P" icon={UserCheck} color="bg-green-600" />
               <LessonNode id="3.3" title="Safe Words" subtitle="Security" icon={Lock} color="bg-green-700" isLast />
            </div>
          </div>

        </div>

        {/* Graduation */}
        <div className="bg-white border-4 border-black rounded-3xl p-8 text-center shadow-hard mt-12">
           <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-green-500">
              <Award className="text-green-600" size={40} />
           </div>
           <h3 className="text-2xl font-bold uppercase font-display mb-2">Graduation</h3>
           <p className="text-slate-500 font-medium text-sm max-w-xs mx-auto">
             Complete all 9 steps to start your journey into financial sovereignty.
           </p>
        </div>

      </div>
    </PageLayout>
  );
};