import React from 'react';
import { PageLayout } from '../components/PageLayout';
import { Send, ExternalLink, Feather } from 'lucide-react';

export const Blog: React.FC = () => {
  return (
    <PageLayout title="Articles" subtitle="Educational Writing">
      <div className="space-y-6">
        <div className="bg-blue-600 text-white p-8 rounded-3xl border-4 border-black shadow-hard relative overflow-hidden flex flex-col items-center text-center">
           <div className="relative z-10 flex flex-col items-center">
             <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center border-2 border-white/20 mb-6">
                <Send size={40} />
             </div>
             <h3 className="text-3xl font-bold uppercase font-display leading-none mb-2">Join the School</h3>
             <p className="text-white/60 font-bold uppercase text-sm mb-6 tracking-widest">Updates & Education</p>
             <p className="text-lg font-medium leading-relaxed mb-8 max-w-xl text-white/90">
               Bitcoin School Kenya publishes all educational articles and community updates exclusively on Telegram.
             </p>
             <a 
               href="https://t.me/bitcoinschoolkenya"
               target="_blank"
               rel="noopener noreferrer"
               className="inline-flex items-center gap-2 bg-white text-blue-600 px-8 py-4 rounded-xl font-bold uppercase text-xl hover:bg-slate-100 transition-colors shadow-lg"
             >
               Join Telegram <ExternalLink size={20} />
             </a>
           </div>
           <div className="absolute -right-10 -bottom-10 opacity-10 rotate-12">
              <Feather size={240} />
           </div>
        </div>
      </div>
    </PageLayout>
  );
};