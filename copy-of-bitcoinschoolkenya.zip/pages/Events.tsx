import React from 'react';
import { PageLayout } from '../components/PageLayout';
import { 
  Calendar, 
  ExternalLink,
  Send,
  Users,
  Mic2,
  Coffee
} from 'lucide-react';

export const Events: React.FC = () => {
  return (
    <PageLayout title="Events" subtitle="In-Person Gatherings">
      <div className="space-y-8">

        {/* --- TELEGRAM REDIRECT HERO --- */}
        <div className="bg-blue-600 text-white p-8 rounded-3xl border-4 border-black shadow-hard flex flex-col items-center text-center relative overflow-hidden">
           <div className="relative z-10">
              <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-white/20">
                 <Send size={40} className="text-white" />
              </div>
              <h3 className="font-display font-bold uppercase text-3xl mb-4">Stay Informed</h3>
              <p className="text-white font-bold text-lg leading-tight mb-8 max-w-lg mx-auto">
                Join our Telegram group to be the first to know when we are organizing a <strong>Meetup</strong>, <strong>Workshop</strong>, or <strong>Conference</strong>.
              </p>
              <a 
                href="https://t.me/bitcoinschoolkenya" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-white text-blue-600 px-10 py-5 rounded-2xl font-bold uppercase text-xl shadow-hard-sm hover:translate-y-[2px] hover:shadow-none transition-all border-2 border-black"
              >
                Join Telegram <ExternalLink size={20} />
              </a>
           </div>
           
           {/* Decorative Background Icon */}
           <div className="absolute -right-12 -bottom-12 opacity-10 rotate-12">
              <Calendar size={240} />
           </div>
        </div>

        {/* --- WHAT WE ORGANIZE --- */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-6 text-center">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-black">
                 <Coffee className="text-orange-500" size={24} />
              </div>
              <h4 className="font-bold uppercase text-sm mb-2">Meetups</h4>
              <p className="text-xs text-slate-500 font-medium">Casual coffee chats and community gatherings.</p>
           </div>
           
           <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-6 text-center">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-black">
                 <Mic2 className="text-blue-500" size={24} />
              </div>
              <h4 className="font-bold uppercase text-sm mb-2">Workshops</h4>
              <p className="text-xs text-slate-500 font-medium">Deep dives into wallets, security, and lightning.</p>
           </div>

           <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-6 text-center">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-black">
                 <Users className="text-green-500" size={24} />
              </div>
              <h4 className="font-bold uppercase text-sm mb-2">Conferences</h4>
              <p className="text-xs text-slate-500 font-medium">Larger events featuring local and global speakers.</p>
           </div>
        </div>

        <div className="bg-slate-900 text-white p-6 rounded-2xl border-4 border-black text-center shadow-hard">
           <p className="text-sm font-bold uppercase tracking-widest text-[#F7931A]">#KEEP SPEDN</p>
           <p className="text-xs text-slate-400 italic mt-2">"Building the circular economy, one event at a time."</p>
        </div>

      </div>
    </PageLayout>
  );
};