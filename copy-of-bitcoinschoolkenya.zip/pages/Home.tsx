import React, { useEffect } from 'react';
import { Tile } from '../components/Tile';
import { 
  Zap, 
  MapPin, 
  Newspaper, 
  HandHeart, 
  Mail, 
  Users
} from 'lucide-react';

export const Home: React.FC = () => {
  
  useEffect(() => {
    // Ensure the body has the core ocean gradient
    document.body.style.background = 'linear-gradient(135deg, #003366 0%, #0077be 50%, #00a8cc 100%)';
    document.body.style.backgroundAttachment = 'fixed';
  }, []);

  const tileStyle = "border-[#0077be] shadow-[4px_4px_0px_0px_#0077be] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[2px_2px_0px_0px_#0077be]";

  return (
    <div className="max-w-6xl mx-auto pb-12">
      {/* Hero / Welcome */}
      <div className="py-12 px-4 text-center md:text-left md:flex md:items-end md:justify-between mb-6">
        <div>
          <p className="text-white font-bold text-[21px] max-w-lg font-sans tracking-wide drop-shadow-sm opacity-90 mx-auto md:mx-0 italic">
            #keepspedn
          </p>
        </div>
        <div className="hidden md:block">
           <div className="bg-black text-white px-6 py-3 rounded-xl font-bold uppercase text-sm -rotate-2 font-sans shadow-[4px_4px_0px_0px_#0077be] border-2 border-[#0077be]">
             1 BTC = 1 BTC
           </div>
        </div>
      </div>

      {/* App Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-4">
        
        {/* Tool 1 */}
        <Tile 
          title="Start" 
          subtitle="Get a Wallet" 
          description="Download a wallet. Secure your seed. Receive your first sats." 
          to="/get-started" 
          icon={Zap}
          className={tileStyle} 
        />
        
        {/* Tool 2 */}
        <Tile 
          title="Spend" 
          subtitle="Shop Local" 
          description="Find merchants across Kenya who accept Bitcoin directly." 
          to="/merchants" 
          icon={MapPin}
          className={tileStyle}  
        />

        {/* Tool 3 */}
        <Tile 
          title="Community" 
          subtitle="Join the School" 
          description="Meetups, workshops, and local trade on Telegram." 
          to="/community" 
          icon={Users}
          className={tileStyle}  
        />

        {/* Tool 4 */}
        <Tile 
          title="Articles" 
          subtitle="Latest News" 
          description="Education and updates from the Kenya Bitcoin community." 
          to="/articles" 
          icon={Newspaper}
          className={tileStyle}  
        />

        {/* Tool 5 */}
        <Tile 
          title="Give" 
          subtitle="Support Us" 
          description="Help us print and gift Bitcoin School resources freely." 
          to="/give" 
          icon={HandHeart}
          iconClassName="text-red-500"
          className={tileStyle}  
        />

        {/* Tool 6 */}
        <Tile 
          title="Contact" 
          subtitle="Reach Out" 
          description="Questions? Send us a message or join the chat." 
          to="/contact" 
          icon={Mail}
          className={tileStyle}  
        />

      </div>
    </div>
  );
};