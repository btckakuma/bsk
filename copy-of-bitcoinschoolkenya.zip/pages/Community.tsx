import React from 'react';
import { PageLayout } from '../components/PageLayout';
import { 
  Send
} from 'lucide-react';

export const Community: React.FC = () => {
  const socials = [
    { name: "Telegram", icon: Send, color: "bg-blue-500", url: "https://t.me/bitcoinschoolkenya", handle: "@bitcoinschoolkenya" },
  ];

  return (
    <PageLayout title="Community" subtitle="Join the School">
      <div className="space-y-6">

        {/* --- SOCIAL MEDIA GRID --- */}
        <div>
          <h3 className="font-display font-bold uppercase text-2xl text-center mb-6">Connect With Us</h3>
          <div className="max-w-md mx-auto">
            {socials.map((social, i) => {
              const Icon = social.icon;
              return (
                <a 
                  key={i}
                  href={social.url}
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-white p-8 rounded-3xl border-4 border-black shadow-hard hover:-translate-y-1 hover:shadow-hard-sm transition-all group flex flex-col items-center text-center"
                >
                  <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 text-white border-2 border-black shadow-sm ${social.color}`}>
                    <Icon size={40} />
                  </div>
                  <h4 className="font-display font-bold uppercase text-2xl mb-1">{social.name}</h4>
                  <p className="text-lg font-bold text-slate-400 font-sans group-hover:text-black transition-colors">
                    {social.handle}
                  </p>
                  <p className="mt-4 text-sm text-slate-500 font-medium">
                    Our primary hub for announcements, discussions, and P2P trade.
                  </p>
                </a>
              );
            })}
          </div>
        </div>

        <div className="bg-slate-50 p-6 rounded-2xl border-2 border-slate-200 text-center">
           <p className="text-sm font-bold text-slate-500 uppercase">Don't Trust, Verify</p>
           <p className="text-xs text-slate-400 mt-2">Beware of impersonators. Always verify handles match @bitcoinschoolkenya.</p>
        </div>

      </div>
    </PageLayout>
  );
};