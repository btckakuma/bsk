import React from 'react';
import { PageLayout } from '../components/PageLayout';
import { useSearchParams } from 'react-router-dom';
import { 
  Store, 
  TrendingUp, 
  ShieldCheck, 
  ArrowRight,
  BookOpen
} from 'lucide-react';

const merchantCourseData = [
  {
    id: 1,
    title: "The Problem (Why)",
    icon: TrendingUp,
    color: "bg-red-500",
    topics: [
      { id: "1.1", title: "What is Money?", description: "Money is a swap tool. Bitcoin is easier to carry than cash or chickens." },
      { id: "1.2", title: "Inflation", description: "Why prices rise and how it steals your business's purchasing power." },
      { id: "1.3", title: "Bank Control", description: "Why you shouldn't need permission to spend or receive your earnings." }
    ]
  },
  {
    id: 2,
    title: "The Solution (What)",
    icon: ShieldCheck,
    color: "bg-orange-500",
    topics: [
      { id: "2.1", title: "Digital Gold", description: "Bitcoin's 21 million limit makes it the perfect store of value." },
      { id: "2.2", title: "The Notebook", description: "How the public ledger keeps the network secure and honest." },
      { id: "2.3", title: "Fast Lightning", description: "How to accept instant payments for your products or services." }
    ]
  },
  {
    id: 3,
    title: "The Practice (How)",
    icon: Store,
    color: "bg-green-500",
    topics: [
      { id: "3.1", title: "Your Wallet", description: "Setting up your first digital wallet to receive payments today." },
      { id: "3.2", title: "Face to Face", description: "The basics of P2P trading and #KeepSpedn in your community." },
      { id: "3.3", title: "Security", description: "How to protect your funds with a proper secret word backup." }
    ]
  }
];

export const MerchantAcademy: React.FC = () => {
  const [_, setSearchParams] = useSearchParams();

  return (
    <PageLayout title="Academy" subtitle="Foundational training for business owners">
      <div className="space-y-8">
        
        <div className="bg-slate-900 border-4 border-black rounded-3xl p-8 shadow-hard text-center text-white relative overflow-hidden">
           <div className="relative z-10">
              <h2 className="text-3xl font-bold uppercase font-display mb-2">Merchant Training</h2>
              <p className="text-slate-400 font-medium">9 core lessons to move your business to the Bitcoin Standard.</p>
           </div>
           <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
              <div className="w-full h-full bg-[radial-gradient(circle,#fff_1px,transparent_1px)] bg-[length:20px_20px]"></div>
           </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
           {merchantCourseData.map((chapter) => (
             <div key={chapter.id} className="bg-white border-4 border-black rounded-3xl overflow-hidden shadow-hard">
                <div className={`p-6 flex items-center gap-4 border-b-4 border-black ${chapter.color} text-white`}>
                   <chapter.icon size={28} />
                   <h3 className="text-xl md:text-2xl font-bold uppercase font-display">Chapter {chapter.id}: {chapter.title}</h3>
                </div>
                <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                   {chapter.topics.map((topic) => (
                     <button 
                       key={topic.id}
                       onClick={() => setSearchParams({ learn: topic.id })}
                       className="p-6 rounded-2xl bg-slate-50 border-2 border-slate-100 text-left hover:border-black hover:bg-white hover:shadow-md transition-all group flex flex-col h-full"
                     >
                        <div className="flex justify-between items-start mb-2">
                           <span className="text-[10px] font-bold uppercase text-slate-400">Lesson {topic.id}</span>
                           <BookOpen size={16} className="text-slate-300 group-hover:text-orange-500 transition-colors" />
                        </div>
                        <h4 className="font-bold uppercase text-sm mb-2 group-hover:text-orange-600 transition-colors">{topic.title}</h4>
                        <p className="text-xs text-slate-500 font-medium leading-relaxed flex-grow">{topic.description}</p>
                        <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-1 text-[10px] font-bold uppercase text-black">
                           START <ArrowRight size={10} />
                        </div>
                     </button>
                   ))}
                </div>
             </div>
           ))}
        </div>

      </div>
    </PageLayout>
  );
};