import React, { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { X, BookOpen, Brain, Trophy, ChevronRight, PenTool, CheckCircle2, AlertCircle, FileText, Flame, Shield, QrCode, Lock, Zap, Clock, Smartphone, Globe } from 'lucide-react';
import { getKnowledge, Tool } from '../data/knowledge';
import { BlankaText } from './BlankaText';

declare global {
  interface Window {
    confetti: any;
  }
}

export const KnowledgeModal: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get('learn');
  const [mode, setMode] = useState<'LEARN' | 'TOOL' | 'QUIZ' | 'SUCCESS'>('LEARN');
  
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [shuffledOptions, setShuffledOptions] = useState<string[]>([]);
  const [wrongShake, setWrongShake] = useState(false);
  const [score, setScore] = useState(0);

  // Tool states
  const [tradeSelection, setTradeSelection] = useState<'NONE' | 'CHICKEN' | 'SATS'>('NONE');
  const [calcAmount, setCalcAmount] = useState(1000);
  const [calcYears, setCalcYears] = useState(5);
  const [bankGateStatus, setBankGateStatus] = useState<'IDLE' | 'PENDING' | 'REJECTED'>('IDLE');
  const [fiatSupply, setFiatSupply] = useState(1);
  const [hashInput, setHashInput] = useState('');
  const [laserRacing, setLaserRacing] = useState(false);
  const [walletBalance, setWalletBalance] = useState(0);
  const [escrowStep, setEscrowStep] = useState(0);
  const [safeMaterial, setSafeMaterial] = useState<'NONE' | 'PAPER' | 'STEEL'>('NONE');
  const [safeStatus, setSafeStatus] = useState<'IDLE' | 'BURNED' | 'SURVIVED'>('IDLE');

  const item = query ? getKnowledge(query) : null;
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (query) {
      setMode('LEARN');
      setCurrentQIndex(0);
      setScore(0);
      setTradeSelection('NONE');
      setBankGateStatus('IDLE');
      setFiatSupply(1);
      setLaserRacing(false);
      setSafeMaterial('NONE');
      setSafeStatus('IDLE');
    }
  }, [query]);

  useEffect(() => {
    if (mode === 'QUIZ' && item) {
      const currentQ = item.quiz[currentQIndex];
      if (currentQ) setShuffledOptions([...currentQ.options].sort(() => Math.random() - 0.5));
    }
  }, [mode, currentQIndex, item]);

  const close = () => {
    const newParams = new URLSearchParams(searchParams);
    newParams.delete('learn');
    setSearchParams(newParams);
  };

  const handleAnswer = (selected: string) => {
    if (!item) return;
    const currentQ = item.quiz[currentQIndex];
    if (selected === currentQ.options[0]) {
      setScore(prev => prev + 1);
      if (currentQIndex < item.quiz.length - 1) setCurrentQIndex(prev => prev + 1);
      else {
        setMode('SUCCESS');
        if (window.confetti) window.confetti({ particleCount: 150, spread: 80, origin: { y: 0.6 } });
      }
    } else {
      setWrongShake(true);
      setTimeout(() => setWrongShake(false), 500);
    }
  };

  const renderToolWidget = (tool: Tool) => {
    switch (tool.name) {
      case 'BitTrade':
        return (
          <div className="text-center space-y-6">
            <div className="flex gap-4">
              <button onClick={() => setTradeSelection('CHICKEN')} className={`flex-1 p-4 rounded-xl border-4 ${tradeSelection === 'CHICKEN' ? 'bg-red-500 text-white border-black' : 'bg-slate-50 border-slate-200'}`}>CHICKEN</button>
              <button onClick={() => setTradeSelection('SATS')} className={`flex-1 p-4 rounded-xl border-4 ${tradeSelection === 'SATS' ? 'bg-orange-500 text-white border-black' : 'bg-slate-50 border-slate-200'}`}>SATS</button>
            </div>
            <div className="h-32 bg-slate-100 rounded-2xl flex items-center justify-center border-2 border-dashed border-slate-300 overflow-hidden">
               {tradeSelection === 'CHICKEN' && <p className="animate-bounce text-4xl">🐔</p>}
               {tradeSelection === 'SATS' && <p className="animate-pulse text-4xl">⚡</p>}
               {tradeSelection === 'NONE' && <p className="text-slate-400 font-bold uppercase">Select a tool</p>}
            </div>
            <p className="text-xs font-bold text-slate-500 uppercase">{tradeSelection === 'CHICKEN' ? "Heavy and loud. Hard to send far away!" : tradeSelection === 'SATS' ? "Light and fast. Sent anywhere instantly!" : "Swap assets..."}</p>
          </div>
        );
      case 'BitCalc':
        const loss = calcAmount - (calcAmount / Math.pow(1.15, calcYears));
        return (
          <div className="bg-slate-900 p-6 rounded-3xl border-4 border-black text-white w-full max-w-xs mx-auto shadow-hard">
             <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Amount (KES)</label>
                  <input type="number" value={calcAmount} onChange={(e) => setCalcAmount(Number(e.target.value))} className="w-full bg-black border border-slate-700 p-2 rounded text-[#F7931A] font-mono outline-none" />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500">Years Saving Cash</label>
                  <input type="range" min="1" max="20" value={calcYears} onChange={(e) => setCalcYears(Number(e.target.value))} className="w-full accent-[#F7931A]" />
                  <p className="text-right text-xs font-bold">{calcYears} Years</p>
                </div>
                <div className="bg-red-950 p-4 rounded-xl border border-red-900 text-center">
                   <p className="text-[10px] font-bold uppercase text-red-400">Buying Power Lost</p>
                   <p className="text-2xl font-bold font-mono text-red-500 leading-none">-{loss.toFixed(0)} KES</p>
                </div>
             </div>
          </div>
        );
      case 'BitGate':
        return (
          <div className="text-center space-y-6">
             <div className={`w-32 h-32 mx-auto rounded-full border-4 border-black flex items-center justify-center transition-colors ${bankGateStatus === 'IDLE' ? 'bg-slate-100' : bankGateStatus === 'PENDING' ? 'bg-yellow-400 animate-pulse' : 'bg-red-500'}`}>
                {bankGateStatus === 'IDLE' && <Lock size={40} />}
                {bankGateStatus === 'PENDING' && <Clock size={40} />}
                {bankGateStatus === 'REJECTED' && <X size={40} color="white" />}
             </div>
             <button onClick={() => { setBankGateStatus('PENDING'); setTimeout(() => setBankGateStatus('REJECTED'), 2000); }} className="bg-black text-white px-8 py-3 rounded-xl font-bold uppercase shadow-hard">Send Payment</button>
             <p className="text-xs font-bold text-red-500 uppercase">{bankGateStatus === 'REJECTED' && "PERMISSION DENIED. REASON: RESTRICTED ACCESS."}</p>
          </div>
        );
      case 'BitScarcity':
        return (
          <div className="text-center space-y-4">
             <div className="flex gap-2 justify-center flex-wrap">
                <div className="w-16 h-16 bg-orange-100 border-2 border-orange-500 rounded flex items-center justify-center font-bold text-orange-600">BTC</div>
                {Array.from({length: fiatSupply}).map((_, i) => (
                   <div key={i} className="w-16 h-16 bg-red-100 border-2 border-red-500 rounded flex items-center justify-center font-bold text-red-600 animate-in zoom-in">FIAT</div>
                ))}
             </div>
             <button onClick={() => setFiatSupply(p => p + 1)} className="bg-red-500 text-white px-4 py-2 rounded-lg font-bold uppercase shadow-hard-sm">Print More Fiat</button>
             <p className="text-xs font-bold text-slate-500 uppercase">BTC is capped. Fiat printing dilutes value!</p>
          </div>
        );
      case 'BitHash':
        return (
          <div className="w-full max-w-xs mx-auto">
             <input value={hashInput} onChange={(e) => setHashInput(e.target.value)} placeholder="Type a message..." className="w-full p-4 border-4 border-black rounded-xl mb-4 outline-none font-mono" />
             <div className="bg-black text-green-400 p-4 rounded-xl font-mono text-[10px] break-all min-h-[60px]">
                {hashInput ? btoa(hashInput).substring(0, 64) : "Truth Notebook Code..."}
             </div>
          </div>
        );
      case 'BitLaser':
        return (
          <div className="space-y-6">
             <div className="relative h-20 bg-slate-100 rounded-xl border-2 border-black overflow-hidden">
                <div className={`absolute top-1/2 -translate-y-1/2 left-0 h-2 bg-blue-500 rounded-full transition-all duration-[3000ms] ${laserRacing ? 'w-[10%]' : 'w-0'}`}></div>
                <div className={`absolute top-1/2 -translate-y-1/2 left-0 h-2 bg-orange-500 rounded-full transition-all duration-[200ms] ${laserRacing ? 'w-[100%]' : 'w-0'}`}></div>
                <div className="absolute right-2 top-1/2 -translate-y-1/2 font-bold text-[10px]">FINISH</div>
             </div>
             <button onClick={() => { setLaserRacing(false); setTimeout(() => setLaserRacing(true), 100); }} className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase shadow-hard">FIRE LASER</button>
          </div>
        );
      case 'BitWallet':
        return (
          <div className="text-center space-y-6">
             <div className="w-40 h-40 bg-white border-4 border-black rounded-2xl mx-auto flex items-center justify-center p-4">
                <QrCode size={100} />
             </div>
             <button onClick={() => setWalletBalance(b => b + 1000)} className="bg-green-500 text-white px-8 py-3 rounded-xl font-bold uppercase shadow-hard">SIMULATE RECEIVE</button>
             <p className="text-2xl font-black font-mono">{walletBalance.toLocaleString()} SATS</p>
          </div>
        );
      case 'BitEscrow':
        return (
          <div className="text-center space-y-6">
             <div className="flex justify-between items-center bg-slate-50 p-4 rounded-xl border-2 border-black font-bold uppercase text-xs">
                <span className={escrowStep === 0 ? "text-orange-500" : ""}>1. Lock</span>
                <span className={escrowStep === 1 ? "text-orange-500" : ""}>2. Pay</span>
                <span className={escrowStep === 2 ? "text-orange-500" : ""}>3. Get</span>
             </div>
             <div className="h-20 flex items-center justify-center text-xl font-bold">
                {escrowStep === 0 && "🔒 Seller locks BTC in Escrow"}
                {escrowStep === 1 && "📱 You send KES to Seller"}
                {escrowStep === 2 && "🎉 Seller releases BTC to You"}
             </div>
             <button onClick={() => setEscrowStep(s => (s + 1) % 3)} className="bg-black text-white px-8 py-3 rounded-xl font-bold uppercase shadow-hard">Next Step</button>
          </div>
        );
      case 'BitSafe':
        return (
          <div className="text-center space-y-6">
             <div className="flex gap-4">
                <button onClick={() => {setSafeMaterial('PAPER'); setSafeStatus('IDLE');}} className={`flex-1 p-4 rounded-xl border-4 ${safeMaterial === 'PAPER' ? 'bg-white text-black border-black' : 'bg-slate-50 border-slate-200'}`}>PAPER</button>
                <button onClick={() => {setSafeMaterial('STEEL'); setSafeStatus('IDLE');}} className={`flex-1 p-4 rounded-xl border-4 ${safeMaterial === 'STEEL' ? 'bg-slate-400 text-black border-black' : 'bg-slate-50 border-slate-200'}`}>STEEL</button>
             </div>
             <div className="h-32 bg-black rounded-2xl flex items-center justify-center relative overflow-hidden">
                {safeMaterial === 'PAPER' && safeStatus === 'IDLE' && <FileText size={48} className="text-white" />}
                {safeMaterial === 'STEEL' && safeStatus === 'IDLE' && <Shield size={48} className="text-slate-400" />}
                {safeStatus === 'BURNED' && <Flame size={64} className="text-red-500 animate-bounce" />}
                {safeStatus === 'SURVIVED' && <CheckCircle2 size={64} className="text-green-500 animate-pulse" />}
             </div>
             <button onClick={() => setSafeStatus(safeMaterial === 'PAPER' ? 'BURNED' : 'SURVIVED')} disabled={safeMaterial === 'NONE'} className="w-full bg-red-600 text-white py-4 rounded-xl font-bold uppercase shadow-hard disabled:opacity-30">TEST FIRE</button>
          </div>
        );
      default: return null;
    }
  };

  if (!query || !item) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 bg-slate-900/90 backdrop-blur-md animate-in fade-in">
      <div className="bg-white border-4 border-black rounded-[2rem] max-w-2xl w-full shadow-glow relative animate-in zoom-in-95 flex flex-col h-[90vh] md:h-[80vh] overflow-hidden">
        <div className="p-4 md:p-6 border-b-4 border-black bg-ocean-primary flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3 text-white overflow-hidden">
             {mode === 'LEARN' && <BookOpen size={24} />}
             {mode === 'TOOL' && <PenTool size={24} />}
             {mode === 'QUIZ' && <Brain size={24} />}
             <div className="overflow-hidden">
               <span className="text-[8px] font-bold uppercase text-black/60 block mb-0.5">Lesson {item.id}</span>
               <BlankaText text={item.title} as="h2" className="text-sm md:text-lg text-white truncate" />
             </div>
          </div>
          <button onClick={close} className="bg-black text-white p-2 rounded-full border-2 border-white shadow-hard-sm active:translate-y-1"><X size={20} /></button>
        </div>

        <div ref={scrollRef} className="overflow-y-auto p-6 md:p-10 bg-white flex-grow relative">
           {mode === 'LEARN' && (
             <div className="animate-in slide-in-from-right duration-300">
               <div className="prose prose-slate prose-lg mb-12" dangerouslySetInnerHTML={{ __html: item.content }} />
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                  <div className="bg-slate-50 p-4 rounded-2xl border-l-4 border-black text-sm italic">"{item.facts.satoshi}" - Satoshi</div>
                  <div className="bg-slate-50 p-4 rounded-2xl border-l-4 border-[#F7931A] text-sm italic">"{item.facts.bitcoiner.quote}" - {item.facts.bitcoiner.name}</div>
               </div>
             </div>
           )}

           {mode === 'TOOL' && (
             <div className="h-full flex flex-col animate-in zoom-in">
               <div className="text-center mb-8">
                 <h3 className="text-2xl font-bold uppercase mb-2">{item.tool.name}</h3>
                 <p className="text-slate-500 text-sm">{item.tool.description}</p>
               </div>
               <div className="flex-grow flex items-center justify-center mb-8">{renderToolWidget(item.tool)}</div>
               <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
                 <h4 className="font-bold uppercase text-[10px] text-yellow-800 mb-2 flex items-center gap-1"><AlertCircle size={10} /> Essential Guide</h4>
                 <ul className="text-[10px] text-yellow-700 font-bold space-y-1">
                   {item.tool.troubleshoot.map((s, i) => <li key={i}>• {s}</li>)}
                 </ul>
               </div>
             </div>
           )}

           {mode === 'QUIZ' && (
             <div className="max-w-md mx-auto animate-in fade-in">
               <div className="mb-8 text-center">
                 <div className="inline-block bg-black text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase mb-4">Question {currentQIndex + 1} / {item.quiz.length}</div>
                 <h3 className="text-xl font-bold leading-tight">{item.quiz[currentQIndex].question}</h3>
               </div>
               <div className={`space-y-3 ${wrongShake ? 'animate-shake' : ''}`}>
                 {shuffledOptions.map((opt, idx) => (
                   <button key={idx} onClick={() => handleAnswer(opt)} className="w-full p-4 rounded-2xl border-4 border-slate-200 bg-white text-base font-bold text-left hover:border-[#F7931A] transition-all flex items-center justify-between group">
                     {opt}
                     <div className="w-4 h-4 rounded-full border-2 border-slate-200 group-hover:border-[#F7931A]"></div>
                   </button>
                 ))}
               </div>
             </div>
           )}

           {mode === 'SUCCESS' && (
             <div className="text-center flex flex-col items-center justify-center py-10 animate-in zoom-in">
                <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center border-4 border-black shadow-hard mb-6 animate-bounce"><Trophy className="text-white" size={48} /></div>
                <h3 className="text-3xl font-bold uppercase mb-2">Lesson Passed!</h3>
                <p className="text-slate-500 font-medium mb-8">You finished Stage {item.id}.</p>
                <button onClick={close} className="w-full max-w-xs bg-black text-white p-4 rounded-2xl font-bold uppercase border-2 border-white shadow-hard-sm">Finish</button>
             </div>
           )}
        </div>

        <div className="p-4 md:p-6 border-t-4 border-black bg-slate-50 shrink-0">
          {mode === 'LEARN' && <button onClick={() => setMode('TOOL')} className="w-full bg-white text-black border-4 border-black font-bold uppercase py-4 rounded-2xl hover:bg-black hover:text-white transition-all shadow-hard active:translate-x-1 active:translate-y-1 active:shadow-none flex items-center justify-center gap-3 font-display">Play With Tool <PenTool size={20} /></button>}
          {mode === 'TOOL' && <button onClick={() => setMode('QUIZ')} className="w-full bg-black text-white font-bold uppercase py-4 rounded-2xl hover:bg-slate-800 transition-all shadow-hard active:translate-x-1 active:translate-y-1 active:shadow-none flex items-center justify-center gap-3 font-display">Take Quiz <ChevronRight size={20} /></button>}
        </div>
      </div>
    </div>
  );
};